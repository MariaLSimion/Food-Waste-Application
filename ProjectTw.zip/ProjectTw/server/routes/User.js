const express = require("express");
const router = express.Router();
const db = require('../config/db');

router.post("/register",(req,res)=>   //requestul pentru a introduce in baza de date utilizatorul cand acesta se inregistreaza
{
      const firstname = req.body.firstname;    //variabilele trimise din request
      const lastname = req.body.lastname;
      const email = req.body.email;
      const username = req.body.username;
      const password = req.body.password;


    db.query(
        "INSERT INTO users (firstname,lastname,email,username,password) VALUES (?,?,?,?,?);",[firstname,lastname,email,username,password], //insert in baza de date
        (err,results) =>{
            console.log(err);
            res.send(results);
        }
    );
});

router.post("/login",(req,res)=>            //luam atributele utilizatorului din baza de date cand vrem sa ne logam 
{
      const username = req.body.username;
      const password = req.body.password;


    db.query(
        "SELECT * FROM users WHERE username = ?",username,       
        (err,results) =>{
            if(err){
                console.log(err);
            }
            if(results.length > 0){
              if(password == results[0].password){
                  res.json({loggedIn: true, username:username});   // incepem sesiunea utilizatorului
              }else{
                  res.json({loggedIn: false, message:"wrong username/password"}); // cand parola e gresita
                  
              }
            } else{
                res.json({loggedIn: false, message:"user does not exist"});  // cand nu exista utilizatorul 
               
            }
        
        }
    );
});


module.exports = router;
