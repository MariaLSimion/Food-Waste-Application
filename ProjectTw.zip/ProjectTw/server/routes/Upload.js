const express = require("express");
const router = express.Router();
const db = require('../config/db');

router.post("/",(req,res)=>        // inseram postarile in baza de date
{
     const foodName = req.body.foodName;
     const description = req.body.description;
     const expirationDate = req.body.expirationDate; //variabilele trimise din request
     const type = req.body.type;
     const user = req.body.user;
    db.query(
        "INSERT INTO posts (FoodName,Description,ExpirationDate,Type,User) VALUES (?,?,?,?,?);",[foodName,description,expirationDate,type,user], //inseram in baza de date
        (err,results) =>{
            console.log(err);
            res.send(results);
        }
    );
});


router.get("/", (req,res)=>{
    db.query("SELECT * FROM posts",(err,results)=>{    //luam postarile din baza de date
        if(err) {
            console.log(err);
                }
        res.send(results);
    })
})

/*router.post("/",(req,res)=>{
    const userClaiming = req.body.userClaiming;
    const postId = req.body.postId;
      bd.query("INSERT INTO claims (userClaiming,postId) VALUES (?,?)",[userClaiming,postId],(err,results)=>{  //incercare de a face o tabela pentru produsele claimed
        if(err) {
            console.log(err);}
            res.send(results);
        
      });
});
*/

router.post("/",(req,res)=>{
    const postId = req.body.postId;
      bd.query("UPDATE posts SET Claimed = 1 WHERE idPosts = ?",[postId],(err,results)=>{      //incercare de schimbare tabela de postari a stributului claimed . ca default este 0 si s-ar fi schimbat in 1 
        if(err) {
            console.log(err);}
            res.send(results);
        
      });
});

router.get("/byUser/:username", (req,res)=>{
    const userName=req.params.username
    db.query("SELECT * FROM posts WHERE User=?",userName,(err,results)=>{  //luam postarile unui anumit utilizator pentru profil 
        if(err) {
            console.log(err)
                }
        res.send(results)
    })
})


module.exports = router;
