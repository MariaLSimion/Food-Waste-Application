const mysql = require('mysql');
const db = mysql.createConnection({
     host: 'localhost',
     user:'root',
     password:'STUD',
     database:'foodapp'
});

module.exports =db;