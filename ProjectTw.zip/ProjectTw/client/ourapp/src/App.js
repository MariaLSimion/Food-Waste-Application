
import './App.css';
import {BrowserRouter as Router, Route } from 'react-router-dom';
import Home from './pages/Home';
import NavigationBar from './components/NavigationBar';
import Register from './pages/Register';
import Login from './pages/Login';
import Footer from './components/Footer';
import Upload from './pages/Upload';
import Profile from './pages/Profile';

function App() {
  return(
  <>
  <NavigationBar/>
   <Router>
    <Route path="/" exact render={()=><Home/>} />   {/* In router punem caile */}
    <Route path="/register" exact render={()=><Register/>} />
    <Route path="/login" exact render={()=><Login/>} />
    <Route path="/upload" exact render={()=><Upload/>} />
    <Route path="/profile" exact render={() =><Profile/>} />
   </Router>
  <Footer/>
   </>
  );
}

export default App;
