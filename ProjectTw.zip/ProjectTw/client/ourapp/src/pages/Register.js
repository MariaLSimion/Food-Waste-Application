import React, { useState } from "react";
import "./Register.css";
import Axios from 'axios';
import {useHistory} from 'react-router-dom';
function Register(){
    const [firstname,setFirstName] = useState("");
    const [lastname,setLastName] = useState("");    //variabilele din form declarate
    const [email,setEmail] = useState("");
    const [username,setUserName] = useState("");
    const [password,setPassword] = useState("");
    let history = useHistory();   //pentru redirectionare
    const registerUser = () =>{
       
           Axios.post("http://localhost:3001/user/register",{   //facem un request catre backend pentru a salva valorile din form in baza de date 
               firstname:firstname, 
               lastname:lastname,    //trimitem variabilele
               email:email,
               username:username,
               password:password
           }).then((response)=> {
                 console.log(response);
           });
           history.push("/login");  //redirectionam catre login
    };

    return(
     <div className="RegisterMainDiv">
        <div className="FormRegister">
            <h1 className="RegistrationHeader">Register</h1>
           <input type="text"
               placeholder="First Name" 
              onChange={(event)=>{setFirstName(event.target.value);}}  
              />

           <input type="text" placeholder="Last Name"
           onChange={(event)=>{setLastName(event.target.value);}}    //luam din form si adaugam in variabile 
           />

           <input type="text" placeholder="Email"
           onChange={(event)=>{setEmail(event.target.value);}}
           />

           <input type="text" placeholder="Username"
           onChange={(event)=>{setUserName(event.target.value);}}
           />

           <input type="password" placeholder="Password"
           onChange={(event)=>{setPassword(event.target.value);}}
           />
           <button onClick={registerUser}>Register</button>   {/* cand apasam pe buton apelam functia*/}
        </div>
     </div>
    );
}

export default Register;