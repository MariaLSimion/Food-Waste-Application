import React, { useEffect,useState } from 'react';
import "./Home.css";
import Axios from "axios";
function Home(){
    const [uploads, setUploads] = useState([]);    //contine postarile
    useEffect(()=>{
        if(!localStorage.getItem("loggedIn")){     //verificam daca este un utilizator logat 
            localStorage.setItem("loggedIn",false);
        }
    },[]);
    useEffect(()=>{
        Axios.get("http://localhost:3001/upload").then((response) => {      //trimitem un request catre backend pentru a obtine postarile facute de utilizatori si de ale afisa pe home
            setUploads(response.data);
        });
    },[]);

    const claimFood = (id) =>{
        Axios.post("http://localhost:3001/upload",{postId:id}).then((response)=>{   //aici am incercat sa trimitem un request catre backend pentru a schimba atributul claimed din tabela care contine postarile
            console.log("you claimed this product");
        })
    }

    return(
        <div className="Home">
            {uploads.map((val) => {           // postarile se vor pastra intr un map, val reprezinta o postare
                return(
                    <div className="Post" key={val.idPosts} id="post">       {/* fiecare postare din div are o cheie unica pentru a putea fi recunoscuta si asfel lucram cu postarile*/}
                        <div className="Content">
                            <div>
                            <div className="FoodName">Food Name: {val.FoodName}</div>    {/* Pentru a constri postarea vom adauga in divuri atributele din tabela postarilor. Atributele le obtinem in urma requestului catre backend ca raspuns*/}  
                            <div className="exp" onMouseOver={()=>{           //pentru a anunta utilizatorul de termenul de expirare facem un event pe mouseover
                              var expirationDate = val.ExpirationDate;
                              var today = new Date();
                              var date = today.getFullYear()+"-"+(today.getMonth()+1+"-"+today.getDate());
                              var date1 = date.toString();
                              var date2 = new Date(date1);
                              var year = expirationDate.substring(0,4);
                              var month = expirationDate.substring(6,7);              //aceste linii de cod calculeaza numarul de zile ramase
                              var day = expirationDate.substring(8,10);
                              var expirationDate1 = year+"-"+month+"-"+day;
                              var expirationDate2 = new Date(expirationDate1);
                              var difTime = expirationDate2.getTime() - date2.getTime();
                              var difDays = difTime/(1000 * 3600 * 24);
                              var expDivs = document.getElementsByClassName("exp");   //luam intr un array divurile in care se anunta valabilitatea
                              var i = val.idPosts-1;   // cheia noastra porneste de la 1 asa ca vom scade 
                              if(difDays < 10) {         //daca mai sunt 10 zile pana produsul expira 
                                expDivs[i].innerHTML = "The product will expire soon!";     //se schimba continutul din div 
                                expDivs[i].style.color = "#FF0000";
                                expDivs[i].style.fontSize = "15px";              //facem niste schimbari de stil
                                expDivs[i].style.fontWeight = "bold";
                                expDivs[i].style.fontFamily = "monospace";
                              }
                             
                              console.log(difDays);
                            }}>WARNING</div>
                            </div>
                            <div className="Info">
                             <div className="ExpirationDate">Expiration date:{val.ExpirationDate}</div>
                             <div className="Type">Type:{val.Type}</div>
                             <div className="User">User:{val.User}</div>
                             </div>
                             <div className="Description">Description: {val.Description}</div>
                             <div className='DivButton'>
                      <button key={"-"} className="ButtonClaim" id = "ClaimButton" onClick={()=>{             //punem un buton pentru ca un utilizator sa poata sa obtina produsul 
                           claimFood(val.idPosts);
                           var buttons = document.getElementsByClassName("ButtonClaim");
                            for(let i = 0;i<buttons.length;i++){
                                buttons[i].key = val.idPosts;
                            }
                            var divs = document.getElementsByClassName("ClaimedDiv");
                            for(let i = 0;i<divs.length;i++){
                                divs[i].key = val.idPosts;
                            }
                            var i = val.idPosts-1;        
                            divs[i].innerHTML = "Claimed";   //schimbam ce scrie pe buton cand se apasa
                            buttons[i].style.display = "none";    //nu se mai poate apasa pe buton dupa pentru ca produsul nu mai e valabil

                      }
                    }>Claim</button>
                          </div>
                          <div id="claimed" className='ClaimedDiv' key="-">
                                Unclaimed
                              </div>
                        </div>
                  
                    </div>
                );
            })}
        </div>
    );
}
export default Home;