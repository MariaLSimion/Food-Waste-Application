import React, { useState } from "react";
import "./Upload.css";
import Axios from "axios";
import {useHistory} from 'react-router-dom';

function Upload(){
    const [foodName, setFoodName] = useState('');
    const [description, setDescription] = useState('');
    const [expirationDate, setExpirationDate] = useState('');  
    const [type, setType] = useState('');
    let history = useHistory();

    const upload = () =>{
       
        Axios.post("http://localhost:3001/upload",{  //facem request catre backend pentru a adauga in baza de date postarile 
            foodName:foodName,
            description:description,   //trimitem variabilele
            expirationDate:expirationDate,
            type:type,
            user:localStorage.getItem("username")  //trimitem si username-ul 
        }).then((response)=> {
              console.log(response);
              history.push('/')  //ne redirectionam catre home
        });

 };

    return (
        <div className="Upload">
           <h1 className="UploadFoodHeader">Upload Food Item</h1>
           <div className = "UploadFood">
           <input type="text"
            placeholder="Food Name" 
              onChange={(event)=>{setFoodName(event.target.value);}}  //luam din form si adaugam in variabila
              />

           <input type="text" 
           placeholder="Description"
           onChange={(event)=>{setDescription(event.target.value);}}
           />
            <input type="date" 
           placeholder="Expiration Date"
           onChange={(event)=>{setExpirationDate(event.target.value);}}
           />
         

          <select className="FoodsSelect" id="type" onChange={(event)=>{setType(event.target.value);}}>
          <option value="-">-</option>
          <option value="FruitsAndVegetables">Fruits and Vegetables</option>
          <option value="Meat">Meat</option>
          <option value="Drinks">Drinks</option>
          <option value="Desert">Desert</option>
          <option value="CannedFood">Canned Food</option>
          <option value="FrozenFood">Frozen Food</option>
          <option value="GranesPasta">Granes and Pasta</option>
          <option value="DairyFood">Dairy Food</option>
          <option value="Snacks">Snacks</option>
          </select>

         <button onClick={upload}>Upload</button>  {/* cand apasam pe buton apelam functia*/}
           </div>
        </div>
    );
}
export default Upload;
