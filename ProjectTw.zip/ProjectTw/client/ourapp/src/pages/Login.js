import React,{useState} from "react";
import './Login.css';
import Axios from "axios";
import {useHistory} from 'react-router-dom';
function Login(){

  const [username, setUsername]=useState("");
  const [password, setPassword]=useState("");
  const [errorMessage, setErrorMessage] =useState("");
  let history = useHistory();   //folosim history pentru redirectionare pe alta pagina
  const loginUser =()=>{
      Axios.post("http://localhost:3001/user/login", {   //facem un request catre backend pentru a verifica in baza de date
          username: username,  //trimitem username-ul si parola scrise de utilizator
          password: password}).then((response)=>{
          if(response.data.loggedIn){    //daca exista acest utilizator si ne logam 
              localStorage.setItem("loggedIn",true);  //trimitem in localStorage variabila loggedIn care devine true
              localStorage.setItem("username", response.data.username);    // trimitem si numele de utilizator a persoanei care s-a logat 
              history.push("/");      // ne redirectionam cand suntem logati 
          }else{
              setErrorMessage(response.data.message);   //trimitem un mesaj de eroare 
          }
      });
  };

    return(
       <div className="LoginMainForm"> 
        <div className="FormLogin">
            <h1 className="LoginHeader">Login</h1>

           <input type="text" placeholder="Username"
           onChange={(event)=>{setUsername(event.target.value);}} //luam din form ce a scris utilizatorul si actualizam username
           />
           <input type="password" placeholder="Password"
           onChange={(event)=>{setPassword(event.target.value);}} //luam din form ce a scris utilizatorul si actualizam username
           />
           <button onClick={loginUser}>Login</button>
             <p className="Error">{errorMessage}</p>   {/* pe buton punem event care sa ne apeleze functia loginUser cand apasam*/}
        </div>
        
       </div>
    );
}

export default Login;