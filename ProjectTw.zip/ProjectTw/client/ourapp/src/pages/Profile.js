import  Axios  from 'axios';
import React, { useEffect, useState } from 'react';
import "./Profile.css";
import pic from './pic.png';
import food from "./food.png";
function Profile()
{   
    const [yourUploads, setYourUploads] = useState([]);
    useEffect(()=>{
        Axios.get(`http://localhost:3001/upload/byUser/${localStorage.getItem("username")}`).then((response)=>{   //prin aceasta functie facem un request care sa ne dea postarile utilizatorului logat, acesta se ia din localStorage
            setYourUploads(response.data);   //actualizam array-ul de postari
        });
    });

    return (
        <div className="Profile">
            
                    <div className="UserInfo">
                <div className="avatarholder">
                    <img src={pic} alt="avatar"className="avatar"/>
                </div>
                
                 <div className="FullName">Username: </div>
                 <div className="username">{localStorage.getItem("username")}</div>  {/*adaugam in div username-ul din LocalStorage */}
                <div className="NrPosts">
                <img src={food} alt="postspic" className='food'/></div>

            </div>
            <div className="UserPosts">
            {yourUploads.map((val) => {
                return(
                   
                    <div className="Post" key = {val.idPosts}>
                        <div className="Content">
                            <div>
                            <div className="FoodName">Food Name: {val.FoodName}</div>
                            <div className="exp" onMouseOver={()=>{
                              var expirationDate = val.ExpirationDate;
                              var today = new Date();
                              var date = today.getFullYear()+"-"+(today.getMonth()+1+"-"+today.getDate());
                              var date1 = date.toString();
                              var date2 = new Date(date1);
                              var year = expirationDate.substring(0,4);
                              var month = expirationDate.substring(6,7);
                              var day = expirationDate.substring(8,10);
                              var expirationDate1 = year+"-"+month+"-"+day;
                              var expirationDate2 = new Date(expirationDate1);
                              var difTime = expirationDate2.getTime() - date2.getTime();
                              var difDays = difTime/(1000 * 3600 * 24);
                              var expDivs = document.getElementsByClassName("exp");
                              var i = val.idPosts-1;
                              if(difDays < 10) {
                                expDivs[i].innerHTML = "The product will expire soon!";
                                expDivs[i].style.color = "#FF0000";
                                expDivs[i].style.fontSize = "15px";
                                expDivs[i].style.fontWeight = "bold";
                                expDivs[i].style.fontFamily = "monospace";
                              }
                             
                              console.log(difDays);
                            }}>WARNING</div>
                            </div>
                            <div className="Info">
                             <div className="ExpirationDate">Expiration date:{val.ExpirationDate}</div>
                             <div className="Type">Type:{val.Type}</div>
                             <div className="User">User:{val.User}</div>
                             </div>
                             <div className="Description">Description: {val.Description}</div>
                    
                        </div>
                  
                    </div>
                    
                );
            })}
            </div>
        </div>
    );
}

export default Profile;