import React from "react";
import './Footer.css';
import fb from'./fb.png';
import instagram from './instagram.png';
import twitter from './twitter.png';
function Footer()
{
    
    return (
        <div className="Footer">
           <footer className="footer">
               <div className="inner-footer">
                   <div className="social-links">
                   <img src={fb} alt="facebook" className="fb" onClick={()=>{
                      // window.location.href = "https://ro-ro.facebook.com";
                      window.open("https://ro-ro.facebook.com","_blank");    // event adaugat pe iconite pentru a redirectiona catre site cand apasam pe acestea
                   }}/>
                   <img src={instagram} alt="instagram" className="instagram" onClick={()=>{
                       window.open("https://www.instagram.com","_blank");
                   }}/>
                   <img src={twitter} alt="twitter" className="twitter" onClick={()=>{
                       window.open("https://twitter.com/?lang=ro","_blank");
                   }}/>
                       <ul>
                           <li className="social-items"><a href="#"><i className="fab fa-facebook"></i></a></li>
                           <li className="social-items"><a href="#"><i className="fab fa-twitter-square"></i></a></li>
                           <li className="social-items"><a href="#"><i className="fab fa-instagram"></i></a></li>
                           
                       </ul>
                   </div>

                   <div className="quick-links">
                       <ul>
                           
                           <li className="quick-items"><a href="#">About Us</a></li>
                           <li className="quick-items"><a href="#">Contact Us</a></li>
                           <li className="quick-items"><a href="#">Services</a></li>
                          
                       </ul>
                   </div>

               </div>

               <div className="outer-footer">
                   Copyright TripleS. All Rights Reserved
               </div>
           </footer>
        </div>
    )
}
export default Footer;