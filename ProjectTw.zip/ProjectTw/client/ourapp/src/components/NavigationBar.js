import React from "react";
import './NavigationBar.css';
import logo from'./Logo2.png';

function NavigationBar(){
    return(
      <div className="NavigationBar">
            <img src={logo} alt="Our site's logo" className="logo"/>
               <a href="/">Home</a>
               <a href= "/register">Register</a>       {/* navbar contine caile catre paginile noastre din proiect si ne redirectioneaza cand apasam  */}
               <a href= "/login">Login</a>  
               <a href = "/upload">Upload</a> 
               <a href = "/profile">Profile</a> 
                </div>
    );
}

export default NavigationBar;