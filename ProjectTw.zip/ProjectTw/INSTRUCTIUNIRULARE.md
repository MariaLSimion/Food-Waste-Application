SERVER: cd server
        npm run devStart

CLIENT: cd client
        cd ourapp
        npm start

